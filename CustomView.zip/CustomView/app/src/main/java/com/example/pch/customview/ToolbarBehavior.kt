package com.example.pch.customview

import android.support.design.widget.CoordinatorLayout
import android.widget.ScrollView

class ToolbarBehavior : CoordinatorLayout.Behavior<ScrollView>(){

}