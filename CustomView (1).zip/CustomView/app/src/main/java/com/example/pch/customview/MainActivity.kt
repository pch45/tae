package com.example.pch.customview

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.v4.content.ContextCompat
import android.util.Log
import android.view.View

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        Log.d("visible", "${View.VISIBLE}")
//        Log.d("visible", "${View.GONE}")
//        val sview = findViewById<PaySwitchMenu>(R.id.customSwitch)
//
//        val handler = Handler()
//        handler.postDelayed( { sview.toggle() },1000)
//
        val nview = findViewById<PayActionMenu>(R.id.customViewNormal1)
    }
}
